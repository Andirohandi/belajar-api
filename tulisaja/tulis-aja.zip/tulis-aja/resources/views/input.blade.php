<!DOCTYPE html>
<html>
    <head>
      <title>Inputan</title>
    </head>
    <body>
      <h1>INPUTAN {{ $name }}</h1>
    </body>
</html>
