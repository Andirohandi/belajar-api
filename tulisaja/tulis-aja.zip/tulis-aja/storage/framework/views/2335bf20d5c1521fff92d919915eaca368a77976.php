<!DOCTYPE html>
<html>
    <head>
      <title>Inputan</title>
    </head>
    <body>
      <h1>INPUTAN <?php echo e($name); ?></h1>
    </body>
</html>
